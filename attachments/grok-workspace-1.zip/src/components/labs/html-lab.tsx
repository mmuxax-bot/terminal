import { AppShell, NativeSelect, ToolRow } from "@/components/app-shell";
import { CodeEditor, type EditorDiagnostic } from "@/components/code-editor";
import { Button } from "@/components/ui/button";
import { hintForJsError, lintWebDoc, type HtmlIssue, type HtmlPane } from "@/lib/html-lint";
import {
  buildHtmlDoc,
  download,
  HTML_SAMPLES,
  loadJSON,
  openHtmlPreview,
  saveJSON,
} from "@/lib/studio";
import { cn } from "@/lib/utils";
import {
  Copy,
  Download,
  Eraser,
  ExternalLink,
  Monitor,
  Play,
  Smartphone,
  Tablet,
} from "lucide-react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Split, Panel, Handle } from "@/components/split";
import { toast } from "sonner";
import type { EditorLang } from "@/lib/cm-theme";

const KEYS = Object.keys(HTML_SAMPLES);
const TABS: { id: HtmlPane; label: string; lang: EditorLang }[] = [
  { id: "html", label: "HTML", lang: "html" },
  { id: "css", label: "CSS", lang: "css" },
  { id: "js", label: "JS", lang: "javascript" },
];

type Doc = { html: string; css: string; js: string };
const DEFAULT = HTML_SAMPLES["Kart dizaynı"];
const PANE_LABEL: Record<HtmlPane, string> = { html: "HTML", css: "CSS", js: "JS" };

export function HtmlLab() {
  const [doc, setDoc] = useState<Doc>(DEFAULT);
  const [tab, setTab] = useState<HtmlPane>("html");
  const [width, setWidth] = useState<"full" | "768" | "390">("full");
  const [hydrated, setHydrated] = useState(false);
  const [live, setLive] = useState(() =>
    buildHtmlDoc(DEFAULT.html, DEFAULT.css, DEFAULT.js, { bridge: true }),
  );
  const [runtime, setRuntime] = useState<HtmlIssue[]>([]);
  const [jumpLine, setJumpLine] = useState(0);
  const [jumpSeq, setJumpSeq] = useState(0);
  const [status, setStatus] = useState<"ok" | "err">("ok");
  const [narrow, setNarrow] = useState(false);
  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  useEffect(() => {
    const saved = loadJSON<Doc | null>("html.doc", null);
    if (saved && typeof saved.html === "string") setDoc(saved);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveJSON("html.doc", doc);
  }, [doc, hydrated]);

  useEffect(() => {
    const q = window.matchMedia("(max-width: 767px)");
    const apply = () => setNarrow(q.matches);
    apply();
    q.addEventListener("change", apply);
    return () => q.removeEventListener("change", apply);
  }, []);

  const built = useMemo(() => buildHtmlDoc(doc.html, doc.css, doc.js), [doc]);
  const bridged = useMemo(
    () => buildHtmlDoc(doc.html, doc.css, doc.js, { bridge: true }),
    [doc],
  );
  const staticIssues = useMemo(
    () => lintWebDoc(doc.html, doc.css, doc.js),
    [doc],
  );

  useEffect(() => {
    setRuntime([]);
    const id = window.setTimeout(() => setLive(bridged), 280);
    return () => window.clearTimeout(id);
  }, [bridged]);

  useEffect(() => {
    const el = iframeRef.current;
    if (el) el.srcdoc = live;
  }, [live]);

  useEffect(() => {
    function onMsg(e: MessageEvent) {
      const d = e.data as {
        source?: string;
        t?: string;
        msg?: string;
        line?: number;
        col?: number;
        file?: string;
        name?: string;
      };
      if (!d || d.source !== "nibras-html" || d.t !== "error") return;
      const file = (d.file || "").toLowerCase();
      const inUser = file.includes("user.js");
      const issue: HtmlIssue = {
        pane: inUser || !file || file === "about:srcdoc" ? "js" : "js",
        line: inUser ? d.line || 1 : d.line || 1,
        column: d.col,
        message: `${d.name || "Error"}: ${d.msg || "Xəta"}`,
        hint: hintForJsError(d.name, d.msg),
      };
      setRuntime((prev) => {
        if (prev.some((p) => p.message === issue.message && p.line === issue.line)) {
          return prev;
        }
        return [...prev, issue].slice(0, 12);
      });
    }
    addEventListener("message", onMsg);
    return () => removeEventListener("message", onMsg);
  }, []);

  const issues = useMemo(() => {
    const seen = new Set<string>();
    const out: HtmlIssue[] = [];
    for (const it of [...staticIssues, ...runtime]) {
      const k = `${it.pane}:${it.line}:${it.message}`;
      if (seen.has(k)) continue;
      seen.add(k);
      out.push(it);
    }
    return out;
  }, [staticIssues, runtime]);

  useEffect(() => {
    setStatus(issues.length ? "err" : "ok");
  }, [issues.length]);

  const onRun = useCallback(() => {
    setLive(bridged);
    const ok = openHtmlPreview(built);
    if (!ok) toast("Yeni səhifə bloklandı — önizləmə burada göstərilir");
  }, [bridged, built]);

  const onChange = useCallback(
    (v: string) => setDoc((d) => ({ ...d, [tab]: v })),
    [tab],
  );

  const jumpTo = useCallback((issue: HtmlIssue) => {
    setTab(issue.pane);
    setJumpLine(issue.line);
    setJumpSeq((n) => n + 1);
  }, []);

  const current = doc[tab];
  const lang = TABS.find((t) => t.id === tab)!.lang;
  const diagnostics: EditorDiagnostic[] = useMemo(
    () =>
      issues
        .filter((i) => i.pane === tab)
        .map((i) => ({ line: i.line, column: i.column, message: i.message })),
    [issues, tab],
  );

  return (
    <AppShell
      lang="html"
      status={status}
      statusLabel={issues.length ? `${issues.length} xəta` : "Canlı önizləmə"}
      actions={
        <Button variant="default" size="lg" className="min-w-[118px] flex-1 md:flex-none" onClick={onRun}>
          <Play className="size-3.5" />
          Başlat
        </Button>
      }
    >
      <ToolRow>
        <NativeSelect
          label="Nümunələr"
          value=""
          className="min-w-[160px] flex-1 sm:flex-none"
          onChange={(k) => {
            if (HTML_SAMPLES[k]) setDoc(HTML_SAMPLES[k]);
          }}
        >
          <option value="">Nümunələr</option>
          {KEYS.map((k) => (
            <option key={k} value={k}>
              {k}
            </option>
          ))}
        </NativeSelect>
        <Button
          size="sm"
          onClick={() => {
            void navigator.clipboard.writeText(current);
            toast("Kod kopyalandı");
          }}
        >
          <Copy className="size-3.5" />
          Kopyala
        </Button>
        <Button size="sm" onClick={() => download("index.html", built, "text/html")}>
          <Download className="size-3.5" />
          .html
        </Button>
        <Button
          size="sm"
          onClick={() => setDoc({ html: "", css: "", js: "" })}
        >
          <Eraser className="size-3.5" />
          Təmizlə
        </Button>
        <div className="ml-auto hidden items-center gap-1 sm:flex">
          {(
            [
              ["full", Monitor],
              ["768", Tablet],
              ["390", Smartphone],
            ] as const
          ).map(([w, Icon]) => (
            <button
              key={w}
              onClick={() => setWidth(w)}
              className={cn(
                "grid size-9 place-items-center rounded-md border border-border text-muted",
                width === w && "border-accent/40 bg-elevated text-fg",
              )}
              aria-label={w}
            >
              <Icon className="size-4" />
            </button>
          ))}
        </div>
      </ToolRow>
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex shrink-0 gap-1 border-b border-border bg-surface px-2 py-1.5">
          {TABS.map((t) => {
            const n = issues.filter((i) => i.pane === t.id).length;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "rounded-md px-3 py-1.5 text-sm",
                  tab === t.id ? "bg-elevated text-fg" : "text-muted hover:text-fg",
                )}
              >
                {t.label}
                {n > 0 ? (
                  <span className="ml-1.5 text-xs text-danger">{n}</span>
                ) : null}
              </button>
            );
          })}
        </div>
        <Split orientation={narrow ? "vertical" : "horizontal"} className="min-h-0 flex-1">
          <Panel defaultSize="52%" minSize="28%" className="min-h-[36%] md:min-h-0">
            <CodeEditor
              key={tab}
              lang={lang}
              value={current}
              onChange={onChange}
              onRun={onRun}
              diagnostics={diagnostics}
              jumpLine={jumpLine}
              jumpSeq={jumpSeq}
            />
          </Panel>
          <Handle className={narrow ? "h-1.5 w-full" : "w-1.5"} />
          <Panel defaultSize="48%" minSize="24%" className="min-h-[36%] bg-elevated md:min-h-0">
            <div className="flex h-full min-h-0 flex-col">
              <div className="flex h-10 shrink-0 items-center justify-between border-b border-border px-3 text-[11px] uppercase tracking-wide text-subtle">
                <span>Önizləmə</span>
                <button
                  className="inline-flex items-center gap-1 normal-case text-muted hover:text-fg"
                  onClick={onRun}
                >
                  <ExternalLink className="size-3.5" />
                  Yeni səhifə
                </button>
              </div>
              <div className="min-h-0 flex-1 overflow-auto bg-elevated p-3">
                <div
                  className="relative mx-auto h-full overflow-hidden rounded-md border border-border bg-fg"
                  style={{
                    width: width === "full" ? "100%" : width === "768" ? 768 : 390,
                    maxWidth: "100%",
                    height: "100%",
                  }}
                >
                  <iframe
                    ref={iframeRef}
                    title="Nəticə"
                    sandbox="allow-scripts allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"
                    className="absolute inset-0 h-full w-full border-0 bg-white"
                  />
                </div>
              </div>
            </div>
          </Panel>
        </Split>
        {issues.length > 0 ? (
          <div className="max-h-36 shrink-0 overflow-auto border-t border-danger/35 bg-danger/10">
            <p className="sticky top-0 border-b border-danger/20 bg-danger/10 px-3 py-1.5 text-[11px] uppercase tracking-wide text-danger">
              Xətalar — səbəb aşağıda, kodda qırmızı sətir
            </p>
            <ul className="px-3 py-2">
              {issues.map((it, i) => (
                <li key={`${it.pane}-${it.line}-${i}`}>
                  <button
                    className="flex w-full flex-col items-start gap-0.5 rounded-sm py-1 text-left hover:bg-danger/10"
                    onClick={() => jumpTo(it)}
                  >
                    <span className="font-mono text-[13px] text-danger">
                      ✖ {PANE_LABEL[it.pane]} · sətir {it.line}: {it.message}
                    </span>
                    {it.hint ? (
                      <span className="text-xs text-warn">Səbəb: {it.hint}</span>
                    ) : null}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>
    </AppShell>
  );
}
