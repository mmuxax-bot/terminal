import { createFileRoute, Link } from "@tanstack/react-router";
import { LANGUAGES } from "@/lib/studio";
import { pythonRuntime } from "@/lib/python-runtime";
import { sqlRuntime } from "@/lib/sql-runtime";
import { ArrowUpRight, Braces, Code2, Database, FileCode, Terminal } from "lucide-react";
import { useEffect, type ComponentType } from "react";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [{ title: "NibrasCode Studio" }],
  }),
});

const ICONS: Record<string, ComponentType<{ className?: string }>> = {
  python: Terminal,
  html: FileCode,
  javascript: Braces,
  sql: Database,
  c: Code2,
};

function Home() {
  useEffect(() => {
    const id = window.setTimeout(() => {
      pythonRuntime.ensure();
      sqlRuntime.ensure();
    }, 1200);
    return () => window.clearTimeout(id);
  }, []);

  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="bg-grid pointer-events-none absolute inset-0 opacity-70" />
      <div className="relative mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-5 py-6 sm:px-8">
        <header className="flex items-center justify-between">
          <p className="text-lg font-semibold tracking-tight">
            Nibras<span className="text-accent">Code</span>
          </p>
          <p className="text-xs tracking-[0.18em] text-subtle">Studio</p>
        </header>

        <section className="flex flex-1 flex-col justify-center py-10 sm:py-16">
          <p className="text-sm font-medium text-accent">Limitsiz brauzer IDE</p>
          <h1 className="mt-3 max-w-2xl text-balance text-4xl font-medium leading-tight tracking-tight sm:text-5xl">
            Beş dil. Bir studio. Heç nə quraşdırmadan.
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-base leading-relaxed text-muted">
            Python, HTML/CSS, JavaScript, SQL və C — kodu burada yazın, dərhal işə salın.
            Vaxt limiti yoxdur. Nəticə sizin brauzerinizdə qalır.
          </p>

          <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
            {LANGUAGES.map((l) => {
              const Icon = ICONS[l.id];
              return (
                <Link
                  key={l.id}
                  to={l.path}
                  className="group flex flex-col rounded-xl border border-border bg-surface p-5 transition-colors duration-200 hover:border-accent/35 hover:bg-elevated"
                >
                  <div className="flex items-center justify-between">
                    <span className="grid size-9 place-items-center rounded-md border border-border bg-elevated text-accent">
                      <Icon className="size-4" />
                    </span>
                    <ArrowUpRight className="size-4 text-subtle transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-accent" />
                  </div>
                  <h2 className="mt-5 text-lg font-medium">{l.label}</h2>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted">{l.detail}</p>
                  <p className="mt-4 text-xs uppercase tracking-wide text-subtle">{l.blurb}</p>
                </Link>
              );
            })}
          </div>

          <ul className="mt-12 flex flex-wrap gap-x-6 gap-y-2 text-sm text-subtle">
            <li>Ctrl+Enter — işə sal</li>
            <li>Avtomatik yaddaş</li>
            <li>Azərbaycanca xəta izahı</li>
            <li>numpy / pandas / matplotlib</li>
          </ul>
        </section>
      </div>
    </div>
  );
}
