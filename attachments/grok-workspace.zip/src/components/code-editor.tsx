import CodeMirror from "@uiw/react-codemirror";
import { editorExtensions, type EditorLang } from "@/lib/cm-theme";
import { cn } from "@/lib/utils";
import { useMemo } from "react";

type Props = {
  lang: EditorLang;
  value: string;
  onChange: (v: string) => void;
  onRun: () => void;
  className?: string;
};

export function CodeEditor({ lang, value, onChange, onRun, className }: Props) {
  const extensions = useMemo(() => editorExtensions(lang, onRun), [lang, onRun]);

  return (
    <div className={cn("h-full min-h-0 overflow-hidden bg-panel", className)}>
      <CodeMirror
        value={value}
        height="100%"
        theme="dark"
        extensions={extensions}
        onChange={onChange}
        basicSetup={{
          lineNumbers: true,
          foldGutter: true,
          highlightActiveLine: true,
          autocompletion: true,
          indentOnInput: true,
          bracketMatching: true,
        }}
      />
    </div>
  );
}
