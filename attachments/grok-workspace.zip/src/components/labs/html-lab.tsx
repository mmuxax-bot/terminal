import { AppShell, NativeSelect, ToolRow } from "@/components/app-shell";
import { CodeEditor } from "@/components/code-editor";
import { Button } from "@/components/ui/button";
import {
  buildHtmlDoc,
  download,
  HTML_SAMPLES,
  loadJSON,
  saveJSON,
} from "@/lib/studio";
import { cn } from "@/lib/utils";
import { Copy, Download, Eraser, Monitor, Smartphone, Tablet } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Split, Panel, Handle } from "@/components/split";
import { toast } from "sonner";
import type { EditorLang } from "@/lib/cm-theme";

const KEYS = Object.keys(HTML_SAMPLES);
const TABS: { id: "html" | "css" | "js"; label: string; lang: EditorLang }[] = [
  { id: "html", label: "HTML", lang: "html" },
  { id: "css", label: "CSS", lang: "css" },
  { id: "js", label: "JS", lang: "javascript" },
];

type Doc = { html: string; css: string; js: string };
const DEFAULT = HTML_SAMPLES["Kart dizaynı"];

export function HtmlLab() {
  const [doc, setDoc] = useState<Doc>(DEFAULT);
  const [tab, setTab] = useState<"html" | "css" | "js">("html");
  const [width, setWidth] = useState<"full" | "768" | "390">("full");
  const [hydrated, setHydrated] = useState(false);
  const [live, setLive] = useState("");

  useEffect(() => {
    const saved = loadJSON<Doc | null>("html.doc", null);
    if (saved && typeof saved.html === "string") setDoc(saved);
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveJSON("html.doc", doc);
  }, [doc, hydrated]);

  const built = useMemo(() => buildHtmlDoc(doc.html, doc.css, doc.js), [doc]);

  useEffect(() => {
    const id = window.setTimeout(() => setLive(built), 280);
    return () => window.clearTimeout(id);
  }, [built]);

  const onRun = useCallback(() => setLive(built), [built]);
  const onChange = useCallback(
    (v: string) => setDoc((d) => ({ ...d, [tab === "js" ? "js" : tab]: v })),
    [tab],
  );

  const current = tab === "js" ? doc.js : doc[tab];
  const lang = TABS.find((t) => t.id === tab)!.lang;

  return (
    <AppShell
      lang="html"
      status="ok"
      statusLabel="Canlı önizləmə"
      actions={
        <Button variant="default" size="lg" className="min-w-[118px] flex-1 md:flex-none" onClick={onRun}>
          Yenilə
        </Button>
      }
    >
      <ToolRow>
        <NativeSelect
          label="Nümunələr"
          value=""
          className="min-w-[160px] flex-1 sm:flex-none"
          onChange={(k) => {
            if (HTML_SAMPLES[k]) setDoc(HTML_SAMPLES[k]);
          }}
        >
          <option value="">Nümunələr</option>
          {KEYS.map((k) => (
            <option key={k} value={k}>
              {k}
            </option>
          ))}
        </NativeSelect>
        <Button
          size="sm"
          onClick={() => {
            void navigator.clipboard.writeText(current);
            toast("Kod kopyalandı");
          }}
        >
          <Copy className="size-3.5" />
          Kopyala
        </Button>
        <Button size="sm" onClick={() => download("index.html", built, "text/html")}>
          <Download className="size-3.5" />
          .html
        </Button>
        <Button
          size="sm"
          onClick={() => setDoc({ html: "", css: "", js: "" })}
        >
          <Eraser className="size-3.5" />
          Təmizlə
        </Button>
        <div className="ml-auto hidden items-center gap-1 sm:flex">
          {(
            [
              ["full", Monitor],
              ["768", Tablet],
              ["390", Smartphone],
            ] as const
          ).map(([w, Icon]) => (
            <button
              key={w}
              onClick={() => setWidth(w)}
              className={cn(
                "grid size-9 place-items-center rounded-md border border-border text-muted",
                width === w && "border-accent/40 bg-elevated text-fg",
              )}
              aria-label={w}
            >
              <Icon className="size-4" />
            </button>
          ))}
        </div>
      </ToolRow>
      <div className="flex min-h-0 flex-1 flex-col">
        <div className="flex shrink-0 gap-1 border-b border-border bg-surface px-2 py-1.5">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "rounded-md px-3 py-1.5 text-sm",
                tab === t.id ? "bg-elevated text-fg" : "text-muted hover:text-fg",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        <Split orientation="horizontal" className="min-h-0 flex-1">
          <Panel defaultSize="52%" minSize="28%" className="min-h-[40%] md:min-h-0">
            <CodeEditor lang={lang} value={current} onChange={onChange} onRun={onRun} />
          </Panel>
          <Handle className="w-1.5 max-md:h-1.5 max-md:w-full" />
          <Panel defaultSize="48%" minSize="24%" className="min-h-[40%] bg-elevated md:min-h-0">
            <div className="flex h-full min-h-0 flex-col">
              <div className="flex h-10 shrink-0 items-center justify-between border-b border-border px-3 text-[11px] uppercase tracking-wide text-subtle">
                <span>Önizləmə</span>
                <span className="normal-case text-subtle">sandbox</span>
              </div>
              <div className="min-h-0 flex-1 overflow-auto bg-elevated p-3">
                <div
                  className="mx-auto h-full overflow-hidden rounded-md border border-border bg-fg"
                  style={{
                    width:
                      width === "full" ? "100%" : width === "768" ? 768 : 390,
                    maxWidth: "100%",
                    height: "100%",
                  }}
                >
                  <iframe
                    title="Nəticə"
                    sandbox="allow-scripts allow-forms allow-modals allow-popups allow-downloads"
                    srcDoc={live}
                    className="h-full w-full border-0 bg-white"
                  />
                </div>
              </div>
            </div>
          </Panel>
        </Split>
      </div>
    </AppShell>
  );
}
