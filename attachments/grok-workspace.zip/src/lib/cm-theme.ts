import { EditorView, keymap } from "@codemirror/view";
import { Prec } from "@codemirror/state";
import { HighlightStyle, syntaxHighlighting } from "@codemirror/language";
import { tags as t } from "@lezer/highlight";
import { python } from "@codemirror/lang-python";
import { javascript } from "@codemirror/lang-javascript";
import { html } from "@codemirror/lang-html";
import { css } from "@codemirror/lang-css";
import { sql } from "@codemirror/lang-sql";
import { cpp } from "@codemirror/lang-cpp";
import type { Extension } from "@codemirror/state";

export type EditorLang = "python" | "javascript" | "html" | "css" | "sql" | "c";

const highlight = HighlightStyle.define([
  { tag: t.keyword, color: "#7ec8e3" },
  { tag: t.controlKeyword, color: "#7ec8e3" },
  { tag: t.operatorKeyword, color: "#7ec8e3" },
  { tag: t.comment, color: "#5d6d82", fontStyle: "italic" },
  { tag: t.lineComment, color: "#5d6d82", fontStyle: "italic" },
  { tag: t.string, color: "#9dce8a" },
  { tag: t.number, color: "#e6a07c" },
  { tag: t.bool, color: "#e6a07c" },
  { tag: t.null, color: "#e6a07c" },
  { tag: t.function(t.variableName), color: "#82b4e8" },
  { tag: t.function(t.propertyName), color: "#82b4e8" },
  { tag: t.definition(t.variableName), color: "#e8eef6" },
  { tag: t.typeName, color: "#6ec8c0" },
  { tag: t.className, color: "#82b4e8" },
  { tag: t.propertyName, color: "#c5d4e4" },
  { tag: t.tagName, color: "#7ec8e3" },
  { tag: t.attributeName, color: "#6ec8c0" },
  { tag: t.angleBracket, color: "#8b9bb0" },
  { tag: t.operator, color: "#8b9bb0" },
  { tag: t.punctuation, color: "#8b9bb0" },
  { tag: t.meta, color: "#e0c07a" },
  { tag: t.processingInstruction, color: "#e0c07a" },
  { tag: t.regexp, color: "#9dce8a" },
  { tag: t.self, color: "#e6a07c" },
]);

const theme = EditorView.theme(
  {
    "&": {
      height: "100%",
      backgroundColor: "transparent",
      color: "#e8eef6",
      fontSize: "14px",
    },
    ".cm-content": {
      caretColor: "#2fd4bf",
      fontFamily: '"IBM Plex Mono", ui-monospace, Menlo, Consolas, monospace',
      lineHeight: "1.7",
      padding: "14px 0",
    },
    ".cm-gutters": {
      backgroundColor: "transparent",
      color: "#5d6d82",
      border: "none",
    },
    ".cm-lineNumbers .cm-gutterElement": {
      minWidth: "2.6rem",
      padding: "0 10px 0 8px",
    },
  },
  { dark: true },
);

function langExt(lang: EditorLang): Extension {
  switch (lang) {
    case "python":
      return python();
    case "javascript":
      return javascript();
    case "html":
      return html({ autoCloseTags: true });
    case "css":
      return css();
    case "sql":
      return sql();
    case "c":
      return cpp();
  }
}

export function editorExtensions(lang: EditorLang, onRun: () => void): Extension[] {
  return [
    langExt(lang),
    theme,
    syntaxHighlighting(highlight),
    Prec.highest(
      keymap.of([
        {
          key: "Mod-Enter",
          run: () => {
            onRun();
            return true;
          },
        },
      ]),
    ),
  ];
}
